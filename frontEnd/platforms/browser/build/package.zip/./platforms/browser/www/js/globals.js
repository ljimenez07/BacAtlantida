var serverDomain = "http://localhost:8080/"; 
